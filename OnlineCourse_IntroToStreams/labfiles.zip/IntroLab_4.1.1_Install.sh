#!/bin/bash -e

# Use tar silently in normal operation
# If DEBUG is set to a nonempty value,
#   - print each command before executing it
#   - use tar in verbose mode
TAROPT="--extract --file"
if [ -n "$DEBUG" ]
then
   set -o xtrace
   TAROPT="--extract --verbose --file"
fi

# Assume that the install files tarball is in the same directory
# as the install script. This should work regardless of the pwd
# from where the script is invoked.
# Create the install log in the same directory.
DIR=$( cd -P "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
SCRIPT=$( basename "${BASH_SOURCE[0]}" )
BASE="${SCRIPT%.*}"
LOGFILE=$DIR/$BASE.log
TARBALL=$DIR/${BASE}Files.tar.gz
UNINST=${SCRIPT%Install.*}Uninstall.sh

# Write all stdout and stderr output to the log as well
exec >  >(tee --append $LOGFILE)
exec 2> >(tee --append $LOGFILE >&2)

# Cleanup function: Remove any files already installed.
# Try to remove the Toolkits directory after removing the two toolkits from this install;
# if there are other toolkits, let this fail silently. We don't want to remove anything the
# user already had.
cleanup ()
{
   echo ""
   echo "Error encountered or signal received. Removing data and toolkits and other files, and terminating script."
   cd $HOME
   [ -d data ] && rm --recursive --force data
   [ -d Labs ] && rm --recursive --force Labs
   [ -d Toolkits ] && ( rm --recursive --force Toolkits/NextBus Toolkits/com.ibm.streamsx.inet 2>/dev/null ;
                        rmdir --ignore-fail-on-non-empty Toolkits )
   [ -f Desktop/Live_Map.desktop ] && rm Desktop/Live_Map.desktop
   [ -f Desktop/Infinite_Source.desktop ] && rm Desktop/Infinite_Source.desktop
   cd $DIR
   [ -f $UNINST ] && rm $UNINST
   read -n 1 -s -p "Press any key to exit." ; echo ""
   exit 1
}

>$LOGFILE      # Create the logfile, or truncate it if it already exists

shopt -s expand_aliases   # Otherwise, aliases defined here won't take
alias pushd='pushd >/dev/null'
alias popd='popd >/dev/null'

# Check for elementary problems
if [ ! -f $TARBALL ]
then
   echo "Install files archive $TARBALL not found. Installation cancelled."
   read -n 1 -s -p "Press any key to exit." ; echo ""
   exit 1
fi

# About to create files; set trap to clean up after failure or interrupt
trap cleanup INT TERM ERR

echo "Introductory Streams lab installation started."

# Create an uninstall script
echo Creating uninstall script ...
cat >$DIR/$UNINST << 'EOF'
DIR=$PWD
cd $HOME
[ -d data ] && ( echo "Removing data ..." ; rm --recursive --force data )
[ -d Toolkits ] && ( echo "Removing toolkits ..." ;
                     rm --recursive --force Toolkits/NextBus Toolkits/com.ibm.streamsx.inet 2>/dev/null ;
                     rmdir --ignore-fail-on-non-empty Toolkits )
[ -f Desktop/Live_Map.desktop ] && ( echo "Removing desktop launchers ..." ;
                                     rm Desktop/Live_Map.desktop Desktop/Infinite_Source.desktop)
cd $DIR
echo "Uninstall finished."
read -n 1 -s -p "Press any key to exit." ; echo ""
exit 0
EOF
chmod +x $DIR/$UNINST

echo "Installing data files, toolkits, launchers, and projects ..."
pushd $HOME
tar $TAROPT $TARBALL data Toolkits Desktop Labs >>$LOGFILE

# Build the Inet toolkit. Send output only to the log except for the final
# BUILD SUCCESSFUL and Total time lines.
# It's not clear if the build's error exit status or ^C interrupts are
# detected and trapped by this script.
echo "Building the Internet toolkit ..."
pushd $HOME/Toolkits/com.ibm.streamsx.inet
ant | egrep -v 'javac] warning|javac] Note' | tee --append $LOGFILE | tail -2
echo "Internet toolkit build completed."
popd

# Finish up
popd
echo "Introductory Streams lab installation finished in $SECONDS seconds." 
echo "Installation log in $LOGFILE."
echo "Uninstall script in $DIR/$UNINST."
rm $TARBALL
read -n 1 -s -p "Press any key to exit." ; echo ""
rm $DIR/$SCRIPT
