#!/bin/bash -e

# Use tar silently in normal operation
# If DEBUG is set to a nonempty value,
#   - print each command before executing it
#   - use tar in verbose mode
TAROPT=xf
if [ -n "$DEBUG" ]
then
   set -x
   TAROPT=xvf
fi

# Assume that the install files tarball is in the same directory
# as the install script. This should work regardless of the pwd
# from where the script is invoked.
# Create the install log in the same directory.
DIR=$( cd -P "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
SCRIPT=$( basename "${BASH_SOURCE[0]}" )
BASE="${SCRIPT%.*}"
LOGFILE=$DIR/$BASE.log
TARBALL=$DIR/${BASE}Files.tar.gz
UNINST=${SCRIPT%Install.*}Uninstall.sh

# Write all stdout and stderr output to the log as well
exec >  >(tee -a $LOGFILE)
exec 2> >(tee -a $LOGFILE >&2)

# Cleanup function: Remove any files already installed.
# Try to remove the Toolkits directory after removing the two toolkits from this install;
# if there are other toolkits, let this fail silently. We don't want to remove anything the
# user already had.
# It's safe to remove Workspaces, because the script would not have got this far if that
# directory already existed.
cleanup ()
{
   echo "Error encountered or signal received. Removing workspaces and toolkits and other files, and terminating script."
   cd $HOME
   [ -d data ] && rm -rf data
   [ -d Toolkits ] && ( rm -rf Toolkits/NextBus Toolkits/com.ibm.streamsx.inet 2>/dev/null ; rmdir --ignore-fail-on-non-empty Toolkits )
   [ -f Desktop/Live_Map.desktop ] && rm Desktop/Live_Map.desktop
   [ -d Workspaces ] && rm -rf Workspaces
   [ -f $HOME/StreamsStudio/configuration/.settings/org.eclipse.ui.ide.prefs.bak ] && \
         ( cd $HOME/StreamsStudio/configuration/.settings ; mv org.eclipse.ui.ide.prefs.bak org.eclipse.ui.ide.prefs )
   cd $DIR
   [ -f $UNINST ] && rm $UNINST
   read -n 1 -s -p "Press any key to exit." ; echo ""
}

>$LOGFILE      # Create the logfile, or truncate it if it already exists

shopt -s expand_aliases   # Otherwise, aliases defined here won't take
alias pushd='pushd >/dev/null'
alias popd='popd >/dev/null'

# Check for elementary problems
if [ ! -f $TARBALL ]
then
   echo "Install files archive $TARBALL not found. Installation cancelled."
   read -n 1 -s -p "Press any key to exit." ; echo ""
   exit 1
fi

# Create lab workspaces and required files under the user's home directory.
# Layout:
#     ~/
#       data/
#       Desktop/
#       Toolkits/
#               com.ibm.streamsx.inet/
#               NextBus/
#       Workspaces/
#                  workspace1/
#                  workspace2/
#                             Project2/
#                  workspace3/
#                             Project3/
#                  workspace4/
#                             Project4/
#                  workspace5/
#                             Project5/
#                             NextBus/
#
# with appropriate Makefiles in all workspace and project directories.
# One generic Makefile supports all workspaces; likewise for projects.

# Do not overwrite an existing workspace layout
if [ -d "$HOME/Workspaces" ]
then
   echo "$HOME/Workspaces directory already exists. Installation cancelled."
   read -n 1 -s -p "Press any key to exit." ; echo ""
   exit 1
fi

# About to create files; set trap to clean up after failure or interrupt
trap cleanup INT TERM ERR

echo "Introductory Streams lab installation started."

# Create an uninstall script
echo Creating uninstall script ...
cat >$DIR/$UNINST << 'EOF'
DIR=$PWD
cd $HOME
[ -d data ] && ( echo "Removing data ..." ; rm -rf data )
[ -d Toolkits ] && ( echo "Removing toolkits ..." ; rm -rf Toolkits/NextBus Toolkits/com.ibm.streamsx.inet 2>/dev/null ; rmdir --ignore-fail-on-non-empty Toolkits )
[ -f Desktop/Live_Map.desktop ] && ( echo "Removing desktop launcher ..." ; rm Desktop/Live_Map.desktop )
[ -f $HOME/StreamsStudio/configuration/.settings/org.eclipse.ui.ide.prefs.bak ] && \
   ( echo "Restoring Streams Studio workspace history ..." ; cd $HOME/StreamsStudio/configuration/.settings ; mv org.eclipse.ui.ide.prefs.bak org.eclipse.ui.ide.prefs ; cd $HOME )
if [ -d Workspaces ]
then
   read -r -p "Do you want to remove all lab workspaces (y/N)? " RESPONSE
   RESPONSE=${RESPONSE,,}    # tolower
   if [[ $RESPONSE =~ ^(yes|y)$ ]]
   then
      read -r -p "WARNING! This will delete any work you may have done. Are you sure? [y/N] " RESPONSE
      RESPONSE=${RESPONSE,,}    # tolower
      [[ $RESPONSE =~ ^(yes|y)$ ]] && rm -rf Workspaces
   fi
fi
cd $DIR
echo "Uninstall finished."
EOF
chmod +x $DIR/$UNINST

echo "Installing data files, toolkits and workspaces ..."
pushd $HOME
tar $TAROPT $TARBALL data Toolkits Desktop Workspaces >>$LOGFILE

# Build the Inet toolkit. Send output only to the log except for the final
# BUILD SUCCESSFUL and Total time lines.
# It's not clear if the build's error exit status or ^C interrupts are
# detected and trapped by this script.
echo "Building the Internet toolkit ..."
pushd $HOME/Toolkits/com.ibm.streamsx.inet
ant | egrep -v 'javac] warning|javac] Note' | tee --append $LOGFILE | tail -2
echo "Internet toolkit build completed."
popd

echo "Creating workspaces and projects ..."

# Install workspaces and projects, then add Makefiles
echo "$HOME/Workspaces"
pushd $HOME/Workspaces
tar $TAROPT $TARBALL Makefile_Workspaces >>$LOGFILE
mv Makefile_Workspaces Makefile

# Add Makefiles to all workspaces and projects
# Loop over all subdirectories (workspaces)
for w in */
do
   echo "     $w"
   pushd $w
   tar $TAROPT $TARBALL Makefile_workspace >>$LOGFILE
   mv Makefile_workspace Makefile

   # Loop over all subdirectories (projects) but not the remote temp files
   for p in */
   do
      [ "$p" = "RemoteSystemsTempFiles/" ] && continue
      echo "          $p"
      pushd $p
      tar $TAROPT $TARBALL Makefile_Project >>$LOGFILE
      mv Makefile_Project Makefile
      popd
   done
   popd
done

# Build the projects
# This uses recursive make. To speed things along, it uses as many threads as there are cores.
# The downside to this is that it makes the output appear jumbled. It also generates
# warnings ("-jN forced in submake: disabling jobserver mode."); suppress those to avoid confusion.
echo "Building all projects ..."
echo "NOTE: Multiple (`nproc`) make threads started. Build output from multiple projects may appear interspersed."
make --jobs=`nproc` all 2>&1 | grep -v 'jobserver' | tee --append $LOGFILE | egrep '^make -C'
popd

# Prepopulate the workspace history in Streams Studio
# This only works if it's the QSE VM or Streams Studio is installed in the default directory
if [ -d $HOME/StreamsStudio ]
then
   echo "Prepopulating Streams Studio workspace history ..."
   WSP=$HOME/Workspaces/workspace
   sed --in-place=.bak --expression='s/^MAX_RECENT_WORKSPACES.*$/MAX_RECENT_WORKSPACES=6/' \
                       --expression="s:^RECENT_WORKSPACES=.*$:RECENT_WORKSPACES=$HOME/workspace\\\\n${WSP}1\\\\n${WSP}2\\\\n${WSP}3\\\\n${WSP}4\\\\n${WSP}5:" \
                       $HOME/StreamsStudio/configuration/.settings/org.eclipse.ui.ide.prefs
fi

# Finish up
popd
unalias popd
unalias pushd
echo "Introductory Streams lab installation finished in $SECONDS seconds." 
echo "Installation log in $LOGFILE."
echo "Uninstall script in $DIR/$UNINST."
rm $TARBALL
read -n 1 -s -p "Press any key to exit." ; echo ""
rm $DIR/$SCRIPT
